/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music;

import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.swing.JButton;
import javax.swing.JFrame;

public class MainFrame extends JFrame{
    
    MainFrame(){
        super("RoboMusic");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,200);
        setResizable(false);
        setLocationRelativeTo(null);
        
        
        JButton button = new JButton("CLOSE");
        button.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });
        add(button);
        
        setVisible(true);
        
        
    }

    public static void main(String[] args){
        new MainFrame();
        
        try {
            new Music().melody();
        } catch (LineUnavailableException ex) {
            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
}
