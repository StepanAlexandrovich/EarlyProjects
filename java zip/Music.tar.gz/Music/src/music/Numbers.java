/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music;
public class Numbers {
    int border = 4,value;   
    
    public int process(){
        while(true){
            if(value==border)  { value = 1;    }
            else               { value++;      }
            if(border%value==0){ return value; }
        }
    }
}
