/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package music;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

public class Music {      public Music()throws LineUnavailableException{}
    /////// sound
    private AudioFormat af = new AudioFormat(44100,8,1,true,false);     
    private SourceDataLine sdl = AudioSystem.getSourceDataLine(af);
    private byte[] buf = new byte[1];
    ///////// numbers
    private Numbers numbers = new Numbers(); 
    
    private int length = 100,i;
    
    public void melody() throws LineUnavailableException{
        sdl.open(af);
        sdl.start();
        
        for(int i1 = 1;i1<20320;i1++){
            numbers.border = i1;
            
            i++;
            //if(i%5==0){ length++; }
            for(int i = 0;i<length;i++){
                tone(numbers.process(),10,3);
                //tone(60+0*5,3000,3);
                //tone(60+12*5,3000,3);
            }
        }
        
        sdl.drain();
        sdl.stop();
        sdl.close();
    }
    
    public void tone(int hz, int msecs, double vol)throws LineUnavailableException {
        double forAngle = (double)hz/2000;
        
        for (int i=0; i < msecs*8; i++) { 
            double angle = i*forAngle;
            buf[0] = (byte)(Math.sin(angle) * vol);
            sdl.write(buf,0,1);
        }
        
    }
    
}
