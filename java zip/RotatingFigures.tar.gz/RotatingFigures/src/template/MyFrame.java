package template;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    Panel panel = new Panel();
     
    public MyFrame(){
        super("Window");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600,800);
        //setResizable(false);
        
        setLocationRelativeTo(null);
        
        setLayout(null);
        add(panel); 
        
        JButton button = new JButton("next");
        button.addActionListener((ActionEvent e) -> {
            panel.nextMode();
        });
        button.setBounds(1400,0,180,50);
        add(button);
        
        setVisible(true);
        
        new Timer(00,this).start();
    }

    @Override
    public void actionPerformed(ActionEvent e) { panel.repaint(); }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
}
