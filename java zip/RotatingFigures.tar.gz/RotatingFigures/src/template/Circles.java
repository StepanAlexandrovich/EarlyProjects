package template;

public class Circles extends Point{
    static double step = 0.2; 
    static int for1  = 20,for2 = 4;
    
    public final double radius = 175;
    public Circle circle1 = new Circle(+radius,0,step);
    public Circle circle2 = new Circle(-radius,0,step);
    
    public Circles(){ process(); }
    
    @Override
    public void calculation(){
        x[next] = circle1.getX()- circle2.getX();
        y[next] = circle1.getY()- circle2.getY();
          
        for(int i = 0;i<for1;i++){ circle1.process(); }
        for(int i = 0;i<for2;i++){ circle2.process(); }    
    }
}
