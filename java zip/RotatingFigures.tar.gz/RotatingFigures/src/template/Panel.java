package template;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

public class Panel extends JPanel{ 
    private boolean nextMode = false;
    private int mode;
    
    // размеры
    private final int width = 1400,height = 750;
    private int xCenter = width/2,yCenter = height/2-22;
    
    
    // ссылки
    private Circles circles = new Circles();
    // работа с графикой
    private final BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
    private final Graphics g = image.getGraphics();
    private final DynamicColor color = new DynamicColor();
    // динамичные величины
    public int i;
    
    public Panel(){
        this.setBounds(0,0,width,height);
        
        g.setColor(Color.WHITE);
        g.fillRect(0,0,width,height);
    }
    
    @Override
        public void paint(Graphics g){  
            //if(++i<9000){
                circles.process();
                //draw(circles.circle1,Color.RED);
                //draw(circles.circle2,Color.BLUE);
                draw(circles,Color.BLACK);
            //}
            
            g.drawImage(image,0,0,null);
        }
    
    public void draw(Point point,Color color){
        int x1 = (int)point.getX();
        int y1 = (int)point.getY();
        int x2 = (int)point.getXBack();
        int y2 = (int)point.getYBack();
        
        g.setColor(color);
        g.drawLine(x1 + xCenter,y1 + yCenter, x2 + xCenter, y2 + yCenter);
        //g.drawLine(xCenter, yCenter,x2 + xCenter,y2 + yCenter);
        if(nextMode){
            mode++;
            if(mode == 4) { mode = 0; }
            switch(mode){
                case 0: Circles.step = 0.2;
                        Circles.for1 = 20;
                        Circles.for2 = 4;
                        break;
                case 1: Circles.step = 1.1;
                        Circles.for1 = 20;
                        Circles.for2 = 5;
                        break;
                case 2: Circles.step = 200;
                        Circles.for1 = 10;
                        Circles.for2 = 60;
                        break;
                case 3: Circles.step = 250;
                        Circles.for1 = 5;
                        Circles.for2 = 1;
                        break;        
            }
            
            circles = new Circles(); 
            
            g.setColor(Color.WHITE);
            g.fillRect(0,0,width,height);
            nextMode = false;
        }
    }
    
    public void nextMode(){
        nextMode = true;
    }
    
      
}
