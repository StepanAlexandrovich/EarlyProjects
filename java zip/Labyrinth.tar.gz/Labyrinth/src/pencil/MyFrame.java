package pencil;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    public JPanel panel;
    public Labyrinth labyrinth = new Labyrinth(0,0);
    
    public static int mult = 20;
    
    public MyFrame(){
        super("Pencil");
        super.setBackground(Color.GRAY);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(820,850);
        this.setLocationRelativeTo(null);
        this.add(panel = new Panel());
        this.setVisible(true);
        
        new Timer(10,this).start();
    }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        labyrinth.process();
        panel.repaint();
    }

    private class Panel extends JPanel{
        
        
        @Override
        public void paint(Graphics g){
            new Robot(g,labyrinth.pointStart);
            snake((Graphics2D)g);
        }
        
        void snake(Graphics2D g2D){
            g2D.setColor(Color.BLUE);
            g2D.setStroke(new BasicStroke(6.0f));
            Point point = labyrinth.point; 
            for(int i = 0;i<5;i++){
                g2D.drawLine(point.x*mult+2+7,point.y*mult+2+7,point.behind.x*mult+2+7,point.behind.y*mult+2+7);
                point = point.behind;
            }
        }
    }
    
    
        
}
