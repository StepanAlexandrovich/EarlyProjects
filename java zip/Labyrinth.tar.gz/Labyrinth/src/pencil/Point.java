package pencil;

public class Point {
    Point[] points = new Point[4];
    Point behind = this;
    int x,y;
    
    Point(int x,int y,Point behind){
        this.x = x;
        this.y = y;
        if(behind!=null){ this.behind = behind; } 
    }
    
}
