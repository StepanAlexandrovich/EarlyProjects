/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package wrapper;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Helper {
    
    public int border(int vel,int min, int max){
        if(vel>max){ vel = max; }
        if(vel<min){ vel = min; }
        return vel;
    }
    
    public void sleep(int time){
        try {
            Thread.sleep(time);
        } catch (InterruptedException ex) {
            Logger.getLogger(Helper.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
