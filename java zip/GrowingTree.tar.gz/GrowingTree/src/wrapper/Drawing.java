/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wrapper;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Drawing {
    BufferedImage image = new BufferedImage(1200,700, BufferedImage.TYPE_INT_ARGB);
    Graphics g = image.getGraphics();
    int i1;
    
    public Drawing(int i){
        g.setColor(Color.BLUE);
        g.fillRect(0,0,1200,700);
        g.setColor(Color.BLACK);
        
        this.i1 = i;
        recursion(600,600,0,0);
    }
    
    void recursion(int xBefore,int yBefore,double rad,int i){ 
        int x = xBefore - (int)((Math.sin(rad)*i1)/5);
        int y = yBefore - (int)((Math.cos(rad)*i1)/5);
        
        g.drawLine(xBefore,yBefore,x,y);
        if(i<13){
            recursion(x,y,rad+(0.001)*i1,i+1);
            recursion(x,y,rad-(0.001)*i1,i+1);
            
            //recursion(x,y,rad+(0.2),i+1);
            //recursion(x,y,rad-(0.2),i+1);
        }
    }
    
}
