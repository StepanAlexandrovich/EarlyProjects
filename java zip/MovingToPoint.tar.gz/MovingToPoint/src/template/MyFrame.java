package template;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MyFrame extends JFrame implements ActionListener{
    JPanel panel = new Panel();
     
    public MyFrame(){
        super("Window");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1500,800);
        setResizable(false);
        setLocationRelativeTo(null);
        add(panel); 
        setVisible(true);
        new Timer(00,this).start();
    }

    @Override
    public void actionPerformed(ActionEvent e) { panel.repaint(); }
    
    public static void main(String[] args) {
        new MyFrame();
    }
    
}
