package template;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

public class Panel extends JPanel{ 
    // размеры
    private final int width = 1400,height = 750;
    private final int xCenter = width/2,yCenter = height/2;
    // ссылки
    private final Circles circles = new Circles();
    // работа с графикой
    private final BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
    private final Graphics g = image.getGraphics();
    private final DynamicColor color = new DynamicColor();
    // динамичные величины
    public int i;
    
    public Panel(){
        g.setColor(Color.YELLOW);
        g.fillRect(0,0,width,height);
    }
    
    @Override
        public void paint(Graphics g){  
            
                circles.process();
                //draw(circles.circle1,Color.RED);
                //draw(circles.circle2,Color.BLUE);
                draw(circles,color.color1());
            
            g.drawImage(image,0,0,null);
        }
    
    public void draw(Point point,Color color){
        int x1 = (int)point.getX();
        int y1 = (int)point.getY();
        int x2 = (int)point.getXBack();
        int y2 = (int)point.getYBack();
        
        g.setColor(color);
        g.drawLine(x1 + xCenter,y1 + yCenter, x2 + xCenter, y2 + yCenter);
        //g.drawLine(xCenter, yCenter,x2 + xCenter,y2 + yCenter);
    }
      
}
