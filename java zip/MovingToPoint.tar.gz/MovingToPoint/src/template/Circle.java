package template;

public class Circle extends Point{
    private double p,k;
    
    public Circle(double x0,double y0,double p){ 
        x[0] = x0;
        y[0] = y0;
        this.p = p;
        this.k = Math.sqrt(1/(1+p*p));
        k = 0.9999;
    }
  
    @Override
    public void calculation(){
        x[next] = k*(x[now] - p*y[now]);
        y[next] = k*(y[now] + p*x[now]); 
    }
}
