package template;

public class Point { 
    public double x[]={0,0},y[]={0,0};
    ///////////////////////////////////
    public int[] table = {1,0};
    public int now,next=table[now];
    
    public double getX(){ return x[now]; }
    public double getY(){ return y[now]; }
    public double getXBack(){ return x[next]; }
    public double getYBack(){ return y[next]; }
    
    public void process(){    
        calculation();
        next = table[now = table[now]];
    }

    public void calculation() {}
}
