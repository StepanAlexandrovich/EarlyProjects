package template;

public class Circles extends Point{
    public final double radius = 180;
    public Circle circle1 = new Circle(+radius,0,0.01);
    public Circle circle2 = new Circle(-radius,0,0.01);
    
    public Circles(){ process(); }
    
    @Override
    public void calculation(){
        x[next] = circle1.getX()- circle2.getX();
        y[next] = circle1.getY()- circle2.getY();
          
        for(int i = 0;i<5;i++){ circle1.process(); }
        for(int i = 0;i<2;i++){ circle2.process(); }    
    }
}
