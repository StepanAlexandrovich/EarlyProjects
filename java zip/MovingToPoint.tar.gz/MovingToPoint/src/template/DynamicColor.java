package template;

import java.awt.Color;

public class DynamicColor {
    public int value,vector = 1;
    
    public Color color3(int i){
        value = value + vector;
        if(value==255*i) { vector = -1; }
        if(value==00000) { vector = +1; }
        //return new Color(value/i,value/i,value/i);
        //return new Color(value/i,255-value/i,0);
        return new Color(value/i,255-value/i,255-value/i);
    }
    
    public Color color2(int i){
        if(++value>255*i) { value = 0; }
        //return new Color(value/i,000,000);
        return new Color(000,value/i,value/i);
        //return new Color(value/i,value/i,value/i);
    }
    
    public Color color1(){ return Color.BLACK; }
}
